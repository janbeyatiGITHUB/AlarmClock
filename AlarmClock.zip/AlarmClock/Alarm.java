
/**
 * The Alarm class sets an alarm time using the ClockDisplay12 Class. 
 *
 * @author Rama Alkhouli
 * @version 2022.05.31
 */
public class Alarm
{
    // instance variables - replace the example below with your own
    private boolean flag;
    private ClockDisplay12 time; 
    
    /**
     * Constructor for objects of class Alarm.The alarm time is 
     * set to midnight and the alarm is set to flase.
     */
    public Alarm()
    {
        time= new ClockDisplay12();
        flag = false;
            
    }
    
    /**
     * Constructor for objects of class Alarm. The alram time will be set 
     * based on parameters.
     * 
     *@parameter hours The value of the hour (1-12)
     *@parameter minutes The value of the minute (0-59)
     *@parameter amPm declares whether the time is "a.m" or "p.m"
     * @parameter alaramStatu Shows whethere the alarm is on or off
     */
    public Alarm(int hours, int minutes, String amPm, boolean alaramStatus)
    {
        time = new ClockDisplay12(hours, minutes, amPm);
        flag = alaramStatus;
    }
    
    /**
     * sets the time for the alarm based on inputted parameters
     * 
     *@parameter hours The value of the hour (1-12)
     *@parameter minutes The value of the minute (0-59)
     *@parameter amPm declares whether the time is "a.m" or "p.m"
     * 
     */
    public void setTime ( int hours,int minutes,String amPm){
        time.setTime( hours, minutes, amPm);
    }
    
    /**
     * Turns the alarm on
     */
    public void turnOn (){
        flag = true;
    }
    /**
     * Turns the alarm off
     */
    public void turnOff (){
        flag = false;
    }
    
    /**
     *  Returns a String representing the current alarm time. 
     */
    public String getTime (){
        return time.getTime();
    }
    
    /**
     * Shows whether the alarm is on or off
     *  Turns on if alarm is on and off otherwise.
     */
    public boolean isSet(){
        if (flag == false){
            return false;
        }else{
            return true;
        }
    }
}
