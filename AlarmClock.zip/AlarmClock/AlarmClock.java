/**
 * Write a description of class AlarmClock here.
 *
 * @author Milad Zazai
 * @version version 2022.05.31
 */
public class AlarmClock
{
    private ClockDisplay12 time;
    private Alarm alarm;

    /**
     * Constructor for objects of class AlarmClock
     */
    public AlarmClock()
    {
        time = new ClockDisplay12();  
        alarm = new Alarm();
    }

    /**
     * Constructor for objects of class Alarm. The alram time will be set 
     * based on parameters.
     * 
     *@parameter hours The value of the hour (1-12)
     *@parameter minutes The value of the minute (0-59)
     *@parameter amPm declares whether the time is "a.m" or "p.m"
     *@parameter alaramStatus Shows whethere the alarm is on or off
     */
    public AlarmClock(int t_hours, int t_minutes, String t_amPm,
    int a_hours, int a_minutes, String a_amPm, boolean alarmStatus)
    {
        time = new ClockDisplay12(t_hours, t_minutes, t_amPm);
        alarm = new Alarm(a_hours, a_minutes, a_amPm,alarmStatus);
    }
    
    /**
     * Set the time of the display to the specified hour and
     * minute.
     */
    public void setTime (int hours,int minutes,String amPm)
    {
        time.setTime(hours, minutes, amPm);
    }
    
    /**
     * Set the alarm of the display to the specified hour and
     * minute.
     */
    public void setAlarmTime (int hours,int minutes,String amPm)
    {
        alarm.setTime(hours, minutes, amPm);
    }
    
    /**
     * This method should get called once every minute - it makes
     * the clock display go one minute forward.
     * if the alarm time and the current time are the same the alarm 
     * will go off
     */
    public void clockTick()
    {
        time.timeTick();
        if (alarm.getTime().equals (time.getTime()) && isAlarmSet()== true){
            System.out.println("RING RING RING");
            alarm.turnOff();
        }
    }
    
    /**
     * Returns a String representing the current time. 
     */
    public String getTime()
    {
        return time.getTime();
    }
    
    /**
     * Returns a String representing the current alarm time. 
     */
    public String getAlarmTime()
    {
        return alarm.getTime();
    }
    
    /**
     * Turns the alarm on
     */
    public void setAlarm ()
    {
         alarm.turnOn();
    }
    
    /**
     * Turns the alarm off
     */
    public void unsetAlarm ()
    {
        alarm.turnOff();
    }
    
    /**
     * Shows whether the alarm is on or off
     * Turns on if alarm is on and off otherwise.
     */
    public boolean isAlarmSet()
    {
       return alarm.isSet();
    }
}
